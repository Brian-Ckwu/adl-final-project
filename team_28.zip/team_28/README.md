## ADL 2022 Final Project

### Hit Rate Evaluation
To evaluate the hit rate, run
    
    python hit.py --prediction ./output.jsonl

### Reproducibility
To reproduce the `output.jsonl` file, run

    bash run.sh